<?php

namespace Iyzipay\Model;

class PaymentChannel
{
    const MOBILE = "MOBILE";
    const WEB = "WEB";
    const MOBILE_WEB = "MOBILE_WEB";
    const MOBILE_IOS = "MOBILE_IOS";
    const MOBILE_ANDROID = "MOBILE_ANDROID";
    const MOBILE_WINDOWS = "MOBILE_WINDOWS";
    const MOBILE_TABLET = "MOBILE_TABLET";
    const MOBILE_PHONE = "MOBILE_PHONE";
}